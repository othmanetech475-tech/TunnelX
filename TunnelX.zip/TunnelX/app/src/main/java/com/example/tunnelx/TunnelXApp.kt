package com.example.tunnelx

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class TunnelXApp : Application()
