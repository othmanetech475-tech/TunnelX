package com.example.tunnelx.vpn

import android.net.VpnService

// TODO: إنشاء واجهة TUN، تشغيل المحرك على SOCKS 10808، وتمرير الحزم عبر tun2socks.
class TunnelVpnService : VpnService()
