package com.example.tunnelx.data

/** ملف اتصال بخادمك الخاص. كل القيم يدخلها المستخدم، ولا توجد نطاقات جاهزة. */
data class Profile(
    val name: String,
    val protocol: String,
    val address: String,
    val port: Int = 443,
    val uuidOrPassword: String,
    val transport: String = "ws",
    val path: String = "/",
    val host: String = "",
    val sni: String = "",
    val alpn: String = "h2,http/1.1",
    val fingerprint: String = "chrome",
    val allowInsecure: Boolean = false
)
